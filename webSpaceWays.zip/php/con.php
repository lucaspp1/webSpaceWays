<?php
    
    function msg($msg){
        echo "<script> alert($msg); </script>";
    }
    function redirect($msg){
        echo "<script> window.location = '$msg'; </script>";
    }
    $con = new PDO('mysql:host=localhost;dbname=webspaceways', "root", "");
?>

